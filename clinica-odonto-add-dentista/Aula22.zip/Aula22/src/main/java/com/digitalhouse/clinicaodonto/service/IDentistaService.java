package com.digitalhouse.clinicaodonto.service;

import com.digitalhouse.clinicaodonto.model.Dentista;

import java.util.List;

public interface IDentistaService {

    List<Dentista> listDentista();

}
